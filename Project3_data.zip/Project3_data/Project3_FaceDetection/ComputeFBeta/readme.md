This script was originally developed by Liyuan Liu (TA for 2019S)

How to run:

`python ComputeFbeta predicted.json groundtruth.json`

to get the F1 score between generated and the ground truth to measure the performance.