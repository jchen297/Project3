Files in this folder:

1. <u>ComputeFBeta</u>

   It is used for compute f1 score between two json files.

2. <u>Json_Checker_Annotator</u>

   This is a tool can be released to students to check if they generate the json file in correct format.

   It can also help visualize the json results if images are also provided.

3. <u>json_example</u>

   A demo that can be released to students to show how to create json file.

4. <u>Script_Runner</u>

   This is a script that can extract and run each student's submissions and put the executed results along with the results they submitted to check the consistency.